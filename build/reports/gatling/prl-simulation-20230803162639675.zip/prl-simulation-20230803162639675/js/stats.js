var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "67",
        "ok": "67",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "27819",
        "ok": "27819",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "8658",
        "ok": "8658",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "11737",
        "ok": "11737",
        "ko": "-"
    },
    "percentiles1": {
        "total": "778",
        "ok": "778",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22042",
        "ok": "22042",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27112",
        "ok": "27112",
        "ko": "-"
    },
    "percentiles4": {
        "total": "27678",
        "ok": "27678",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 58
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 33
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.004",
        "ok": "0.004",
        "ko": "-"
    }
},
contents: {
"req_cafcas-000-auth-6aee4": {
        type: "REQUEST",
        name: "CAFCAS_000_Auth",
path: "CAFCAS_000_Auth",
pathFormatted: "req_cafcas-000-auth-6aee4",
stats: {
    "name": "CAFCAS_000_Auth",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "67",
        "ok": "67",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "222",
        "ok": "222",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "121",
        "ok": "121",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "60",
        "ok": "60",
        "ko": "-"
    },
    "percentiles1": {
        "total": "98",
        "ok": "98",
        "ko": "-"
    },
    "percentiles2": {
        "total": "131",
        "ok": "131",
        "ko": "-"
    },
    "percentiles3": {
        "total": "204",
        "ok": "204",
        "ko": "-"
    },
    "percentiles4": {
        "total": "218",
        "ok": "218",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.001",
        "ok": "0.001",
        "ko": "-"
    }
}
    },"req_cafcas-000-getb-434ce": {
        type: "REQUEST",
        name: "CAFCAS_000_GetBearerToken",
path: "CAFCAS_000_GetBearerToken",
pathFormatted: "req_cafcas-000-getb-434ce",
stats: {
    "name": "CAFCAS_000_GetBearerToken",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "355",
        "ok": "355",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1022",
        "ok": "1022",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "733",
        "ok": "733",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "240",
        "ok": "240",
        "ko": "-"
    },
    "percentiles1": {
        "total": "778",
        "ok": "778",
        "ko": "-"
    },
    "percentiles2": {
        "total": "840",
        "ok": "840",
        "ko": "-"
    },
    "percentiles3": {
        "total": "986",
        "ok": "986",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1015",
        "ok": "1015",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 75
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 25
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.001",
        "ok": "0.001",
        "ko": "-"
    }
}
    },"req_cafcasapi-000-s-6b731": {
        type: "REQUEST",
        name: "CafcasAPI_000_searchCasesByDates",
path: "CafcasAPI_000_searchCasesByDates",
pathFormatted: "req_cafcasapi-000-s-6b731",
stats: {
    "name": "CafcasAPI_000_searchCasesByDates",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "21018",
        "ok": "21018",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "27819",
        "ok": "27819",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "25121",
        "ok": "25121",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2555",
        "ok": "2555",
        "ko": "-"
    },
    "percentiles1": {
        "total": "25823",
        "ok": "25823",
        "ko": "-"
    },
    "percentiles2": {
        "total": "26855",
        "ok": "26855",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27626",
        "ok": "27626",
        "ko": "-"
    },
    "percentiles4": {
        "total": "27780",
        "ok": "27780",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.001",
        "ok": "0.001",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
