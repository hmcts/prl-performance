var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "12",
        "ok": "9",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "102",
        "ok": "102",
        "ko": "30058"
    },
    "maxResponseTime": {
        "total": "31132",
        "ok": "21495",
        "ko": "31132"
    },
    "meanResponseTime": {
        "total": "9662",
        "ok": "2740",
        "ko": "30427"
    },
    "standardDeviation": {
        "total": "13297",
        "ok": "6634",
        "ko": "498"
    },
    "percentiles1": {
        "total": "476",
        "ok": "444",
        "ko": "30092"
    },
    "percentiles2": {
        "total": "23636",
        "ok": "499",
        "ko": "30612"
    },
    "percentiles3": {
        "total": "30560",
        "ok": "13229",
        "ko": "31028"
    },
    "percentiles4": {
        "total": "31018",
        "ok": "19842",
        "ko": "31111"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7,
    "percentage": 58
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 8
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 3,
    "percentage": 25
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.004",
        "ok": "0.003",
        "ko": "0.001"
    }
},
contents: {
"req_cafcas-000-auth-6aee4": {
        type: "REQUEST",
        name: "CAFCAS_000_Auth",
path: "CAFCAS_000_Auth",
pathFormatted: "req_cafcas-000-auth-6aee4",
stats: {
    "name": "CAFCAS_000_Auth",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "102",
        "ok": "102",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "453",
        "ok": "453",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "293",
        "ok": "293",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "126",
        "ok": "126",
        "ko": "-"
    },
    "percentiles1": {
        "total": "309",
        "ok": "309",
        "ko": "-"
    },
    "percentiles2": {
        "total": "357",
        "ok": "357",
        "ko": "-"
    },
    "percentiles3": {
        "total": "434",
        "ok": "434",
        "ko": "-"
    },
    "percentiles4": {
        "total": "449",
        "ok": "449",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 4,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.001",
        "ok": "0.001",
        "ko": "-"
    }
}
    },"req_cafcas-000-getb-434ce": {
        type: "REQUEST",
        name: "CAFCAS_000_GetBearerToken",
path: "CAFCAS_000_GetBearerToken",
pathFormatted: "req_cafcas-000-getb-434ce",
stats: {
    "name": "CAFCAS_000_GetBearerToken",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "216",
        "ok": "216",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "829",
        "ok": "829",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "497",
        "ok": "497",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "219",
        "ok": "219",
        "ko": "-"
    },
    "percentiles1": {
        "total": "472",
        "ok": "472",
        "ko": "-"
    },
    "percentiles2": {
        "total": "582",
        "ok": "582",
        "ko": "-"
    },
    "percentiles3": {
        "total": "779",
        "ok": "779",
        "ko": "-"
    },
    "percentiles4": {
        "total": "819",
        "ok": "819",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 75
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 25
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.001",
        "ok": "0.001",
        "ko": "-"
    }
}
    },"req_cafcasapi-000-s-6b731": {
        type: "REQUEST",
        name: "CafcasAPI_000_searchCasesByDates",
path: "CafcasAPI_000_searchCasesByDates",
pathFormatted: "req_cafcasapi-000-s-6b731",
stats: {
    "name": "CafcasAPI_000_searchCasesByDates",
    "numberOfRequests": {
        "total": "4",
        "ok": "1",
        "ko": "3"
    },
    "minResponseTime": {
        "total": "21495",
        "ok": "21495",
        "ko": "30058"
    },
    "maxResponseTime": {
        "total": "31132",
        "ok": "21495",
        "ko": "31132"
    },
    "meanResponseTime": {
        "total": "28194",
        "ok": "21495",
        "ko": "30427"
    },
    "standardDeviation": {
        "total": "3892",
        "ok": "0",
        "ko": "498"
    },
    "percentiles1": {
        "total": "30075",
        "ok": "21495",
        "ko": "30092"
    },
    "percentiles2": {
        "total": "30352",
        "ok": "21495",
        "ko": "30612"
    },
    "percentiles3": {
        "total": "30976",
        "ok": "21495",
        "ko": "31028"
    },
    "percentiles4": {
        "total": "31101",
        "ok": "21495",
        "ko": "31111"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 25
},
    "group4": {
    "name": "failed",
    "count": 3,
    "percentage": 75
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.001",
        "ok": "0",
        "ko": "0.001"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
